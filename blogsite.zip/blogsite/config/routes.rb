Rails.application.routes.draw do
  require 'sidekiq/web'
  get 'saved_blogs', to: 'saved_blogs#index', as: 'saved_blogs'
  resources :stories
  resources :statuses
  devise_for :users
  resources :blogs do
    resources :comments, only: [:create, :destroy]
    resources :likes, only: [:create, :destroy]
    member do
      delete :purge_image
    end
    member do
      post 'share'
    end
  end
  resources :blogs, only: [:index, :show] do
    post 'save', to: 'saved_blogs#create'
    delete 'unsave', to: 'saved_blogs#destroy'
  end
  #get 'site/notes'
  root 'site#main'
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html
  # Reveal health status on /up that returns 200 if the app boots with no exceptions, otherwise 500.
  # Can be used by load balancers and uptime monitors to verify that the app is live.
  get "up" => "rails/health#show", as: :rails_health_check
  mount Sidekiq::Web => '/sidekiq'
  
  # Defines the root path route ("/")
  # root "posts#index"
  get 'shared_blogs', to: 'blogs#shared'

  resources :conversations, only: [:index, :create] do
    resources :messages, only: [:index, :create]
  end


  mount ActionCable.server => '/cable'

  get 'conversations/index'
  get 'messages/index'
end
