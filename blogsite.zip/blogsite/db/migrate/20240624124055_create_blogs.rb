class CreateBlogs < ActiveRecord::Migration[7.1]
  def change
    create_table :blogs do |t|
      t.string :blogname
      t.string :blogtext
      t.string :blogauthor

      t.timestamps
    end
  end
end
