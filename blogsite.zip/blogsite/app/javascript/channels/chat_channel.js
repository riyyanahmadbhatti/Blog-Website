import consumer from "channels/consumer"

const yourConversationId = document.getElementById("conversation").getAttribute("data-conversation-id")
console.log("My conversation", yourConversationId)
consumer.subscriptions.create({ channel: "ChatChannel", conversation_id: yourConversationId },{

  connected(){
    console.log("Connected")
  },
  disconnected(){
    console.log("disnnected")

  },
  received(data) {
    // Append the new message to the chat UI
    console.log("Data", data)
    //debugger
    const messageContent = document.createElement('div');
    const all_msgs = document.getElementById("messages")
    const msg_body = `
    <li><strong>${data["email"]}: </strong>${data["message"]["content"]}</li>

    `
    messageContent.innerHTML = msg_body
    all_msgs.appendChild(messageContent)
    // document.getElementById('messages').appendChild("<li>'Test' `${data.message.content}`</li>");
  }
});