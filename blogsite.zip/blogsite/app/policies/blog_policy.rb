class BlogPolicy < ApplicationPolicy
  def index?
    true  # Anyone can view the list of blogs
  end

  def show?
    true  # Anyone can view a single blog
  end

  def create?
    true # Any authenticated user can create blogs
  end

  def update?
    user.admin? || record.user == user  # Admins or the owner of the blog can update
  end

  def destroy?
    user.admin? || record.user == user  # Admins or the owner of the blog can delete
  end

  class Scope < ApplicationPolicy::Scope
    def resolve
      scope.all
    end
  end
end
