class DeleteStoryJob < ApplicationJob
  queue_as :default

  def perform(*args)
    # Do something later
    story = Story.find_by(id: story_id)
    story.destroy if story.present?
  end
end
