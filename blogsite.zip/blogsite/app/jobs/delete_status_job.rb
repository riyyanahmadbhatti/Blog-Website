class DeleteStatusJob < ApplicationJob
  queue_as :default

  def perform(status_id)
    # Do something later
    status = Status.find_by(id: status_id)
    status.destroy if status.present?
  end
end
