class UserMailer < ApplicationMailer
    default from: 'security@mail.barecanvas.com'  # Replace with your email

    def welcome_email(user)
        @user = user
        @url  = 'http://localhost:3000/'  # Replace with your app's login URL
        mail(to: @user.email, subject: 'Welcome to BareCanvas')
    end
end
