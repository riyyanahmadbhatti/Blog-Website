class ChatChannel < ApplicationCable::Channel
  def subscribed
    # Add the current user to a stream
    stream_from "chat_channel_#{params[:conversation_id]}"
  end


  def unsubscribed
    # Remove the current user from the stream
  end
end