# app/models/message.rb

class Message < ApplicationRecord
  belongs_to :user  # Assumes you have a User model with 'has_many :messages'
  validates :content, presence: true
  end
  