class Blog < ApplicationRecord
    belongs_to :user
    has_many_attached :images
    has_many :comments, as: :commentable, dependent: :destroy

    def purge_image
        @blog = Blog.find(params[:id])
        image = @blog.images.find(params[:image_id])
        image.purge
        redirect_to edit_blog_path(@blog), notice: "Image was successfully deleted."
      end

    
    has_many :likes, as: :likeable, dependent: :destroy
    has_many :liking_users, through: :likes, source: :user
    
    has_many :saved_blogs, class_name: 'SavedBlog'
    has_many :saved_by_users, through: :saved_blogs, source: :user

    has_many :blog_shares
    has_many :shared_by_users, through: :blog_shares, source: :user
end


