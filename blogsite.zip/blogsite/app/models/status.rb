class Status < ApplicationRecord
    
    belongs_to :user
end
