class User < ApplicationRecord
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable, :trackable and :omniauthable
  has_many :sent_messages, class_name: 'Message', foreign_key: 'sender_id'
  has_many :received_messages, class_name: 'Message', foreign_key: 'recipient_id'
  has_many :conversations_as_sender, class_name: 'Conversation', foreign_key: 'sender_id'
  has_many :conversations_as_recipient, class_name: 'Conversation', foreign_key: 'recipient_id'
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :validatable

         has_many :blogs
  
  after_create :send_welcome_email
  has_many :comments, dependent: :destroy
  has_many :statuses
  has_many :likes, dependent: :destroy
  def likes?(blog)
    self.likes.exists?(likeable: blog)
  end
  has_many :saved_blogs, class_name: 'SavedBlog'
  has_many :saved_blog_posts, through: :saved_blogs, source: :blog

  has_many :blog_shares
  has_many :shared_blogs, through: :blog_shares, source: :blog

  def admin?
    self.admin
  end
  private

  def send_welcome_email
    UserMailer.welcome_email(self).deliver_now
  end
end
