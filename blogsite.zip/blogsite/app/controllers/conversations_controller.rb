# app/controllers/conversations_controller.rb

class ConversationsController < ApplicationController
    before_action :authenticate_user!
  
    def index
      @conversations = current_user.conversations_as_sender.or(current_user.conversations_as_recipient)
      @users = User.where.not(id: current_user.id).order(:email) # Order users by email (or any other suitable attribute)
    end
  
    def create
      recipient = User.find_by(email: params[:conversation][:recipient_email])
      
      # Ensure recipient exists
      if recipient.nil?
        redirect_to conversations_path, notice: 'Recipient email not found.'
        return
      end
      
      @conversation = Conversation.new(sender: current_user, recipient: recipient)
  
      if @conversation.save
        redirect_to conversation_messages_path(@conversation)
      else
        redirect_to conversations_path, alert: 'Failed to start conversation.'
      end
    end
  end
  