# app/controllers/messages_controller.rb

class MessagesController < ApplicationController
  before_action :authenticate_user!
  before_action :set_conversation

  def index
    @messages = @conversation.messages
    @message = Message.new
  end

  def create
    @message = @conversation.messages.build(message_params)
    @message.user_id = current_user.id  
    if @message.save
      ActionCable.server.broadcast("chat_channel_#{params[:conversation_id]}", {message: @message, email: @message.user.email})
      redirect_to conversation_messages_path(@conversation)
    else
      render :index, alert: @message.errors.full_messages.join(', ')
    end
  end
  

  private

  def set_conversation
    @conversation = Conversation.find(params[:conversation_id])
  end

  def message_params
    params.require(:message).permit(:content)
  end
end
