class SiteController < ApplicationController
  def main
  end
end
