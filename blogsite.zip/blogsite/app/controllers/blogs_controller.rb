class BlogsController < ApplicationController
  before_action :set_blog, only: %i[show edit update destroy]
  before_action :authenticate_user!, except: %i[index show]

  # GET /blogs
  def index
    @blogs = Blog.order(created_at: :desc)
  end

  # GET /blogs/1
  def show
  end

  # GET /blogs/new
  def new
    @blog = Blog.new
    authorize @blog
  end

  # GET /blogs/1/edit
  def edit
    authorize @blog
  end

  # POST /blogs
  def create
    @blog = Blog.new(blog_params)
    @blog.user_id = current_user.id
    authorize @blog

    respond_to do |format|
      if @blog.save
        format.html { redirect_to blog_url(@blog), notice: "Blog was successfully created." }
        format.json { render :show, status: :created, location: @blog }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @blog.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /blogs/1
  def update
    authorize @blog
    respond_to do |format|
      if @blog.update(blog_params)
        format.html { redirect_to blog_url(@blog), notice: "Blog was successfully updated." }
        format.json { render :show, status: :ok, location: @blog }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @blog.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /blogs/1
  def destroy
    authorize @blog
    @blog.destroy

    respond_to do |format|
      format.html { redirect_to blogs_url, notice: "Blog was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  # DELETE /blogs/1/images/1
  def purge_image
    @blog = Blog.find(params[:id])
    image = @blog.images.find(params[:image_id])
    image.purge
    redirect_to @blog, notice: 'Image was successfully deleted.'
  end

  def share
    blog = Blog.find(params[:id])
    receiver_email = params[:shared_with]
    receiver = User.find_by(email: receiver_email)

    if receiver
      BlogShare.create(user: current_user, blog: blog, shared_with: receiver_email)
      flash[:notice] = "Blog shared with #{receiver_email}"
    else
      flash[:notice] = "User with email #{receiver_email} not found"
    end

    redirect_to blogs_path
  end

  def shared
    @received_blog_shares = BlogShare.where(shared_with: current_user.email)
  end

  private

  # Use callbacks to share common setup or constraints between actions.
  def set_blog
    @blog = Blog.find(params[:id])
  end

  # Only allow a list of trusted parameters through.
  def blog_params
    params.require(:blog).permit(:blogname, :blogtext, :blogauthor, :blogid, images: [])
  end
end
