class SavedBlogsController < ApplicationController
  before_action :authenticate_user!
  before_action :set_blog, only: [:create, :destroy]

  def index
    @saved_blogs = current_user.saved_blog_posts.includes(images_attachments: :blob)
  end

  def create
    current_user.saved_blog_posts << @blog unless current_user.saved_blog_posts.include?(@blog)
    render turbo_stream: turbo_stream.replace("save_button_#{@blog.id}", partial: 'blogs/save_button', locals: { blog: @blog })
  end

  def destroy
    current_user.saved_blog_posts.destroy(@blog)
    render turbo_stream: turbo_stream.replace("save_button_#{@blog.id}", partial: 'blogs/save_button', locals: { blog: @blog })
  end

  private

  def set_blog
    @blog = Blog.find(params[:blog_id])
  end
end
