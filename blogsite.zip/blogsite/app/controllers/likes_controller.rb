class LikesController < ApplicationController
  before_action :set_blog

  def create
    @like = current_user.likes.build(likeable: @blog)

    if @like.save
      respond_to do |format|
        format.html { redirect_to @blog }
        format.turbo_stream { render turbo_stream: [turbo_stream.replace("like_button_#{@blog.id}", partial: 'blogs/like_button', locals: { blog: @blog }), turbo_stream.replace("like_count_#{@blog.id}", partial: "blogs/like_count", locals: {blog: @blog})] }
      end
    else
      redirect_to @blog, alert: 'Unable to like this blog.'
    end
  end

  def destroy
    @like = current_user.likes.find(params[:id])

    if @like.destroy
      respond_to do |format|
        format.html { redirect_to @blog }
        format.turbo_stream { render turbo_stream: [turbo_stream.replace("like_button_#{@blog.id}", partial: 'blogs/like_button', locals: { blog: @blog }), turbo_stream.replace("like_count_#{@blog.id}", partial: "blogs/like_count", locals: {blog: @blog})] }
      end
    else
      redirect_to @blog, alert: 'Unable to unlike this blog.'
    end
  end

  private

  def set_blog
    @blog = Blog.find(params[:blog_id])
  end
end
