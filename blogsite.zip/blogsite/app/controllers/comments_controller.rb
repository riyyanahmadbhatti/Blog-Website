class CommentsController < ApplicationController
  before_action :authenticate_user!
  before_action :set_blog
  before_action :set_comment, only: :destroy

  def create
    @comment = @blog.comments.build(comment_params)
    @comment.user_id = current_user.id
    @comment.user_type = current_user.class.name  # Assuming user_type is related to the type of user model
  
    if @comment.save
      respond_to do |format|
        format.html { redirect_to blogs_path }  # Redirect for non-JS clients
        format.turbo_stream { render turbo_stream: turbo_stream.replace("comments_#{@blog.id}", partial: 'blogs/comments', locals: { blog: @blog }) }
      end
    else
      respond_to do |format|
        format.html { redirect_to blogs_path, alert: 'Failed to create comment.' }
      end
    end
  end
  

  def destroy
    @comment.destroy
    respond_to do |format|
      format.html { redirect_to blogs_path, alert: 'Comment was successfully destroyed.' }
      format.turbo_stream { render turbo_stream: turbo_stream.replace("comments_#{@blog.id}", partial: 'blogs/comments', locals: { blog: @blog }) }
    end
  end

  private

  def set_blog
    @blog = Blog.find(params[:blog_id])
  end

  def set_comment
    @comment = @blog.comments.find(params[:id])
  end

  def comment_params
    params.require(:comment).permit(:content)
  end
end
