require "test_helper"

class SiteControllerTest < ActionDispatch::IntegrationTest
  test "should get main" do
    get site_main_url
    assert_response :success
  end
end
