require "test_helper"

class DeleteStatusJobTest < ActiveJob::TestCase
  # test "the truth" do
  #   assert true
  # end
end
